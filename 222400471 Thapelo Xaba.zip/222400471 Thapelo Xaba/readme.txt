Hello  Welcome 
wolcome to My wibsite 
This website  has 2 pages  login and index page, the First page  is login page .You will need to login using your  username  and passsword.
If you don't have an account you can Create one . The are 3 attempte  so if you Enter wrong Password or Username 3 times you will need to contate the  Administrator
The  second page   is where Student will calculate thier avarege and see   that the qualify  to write final exame or not.
Every stundent have to Eneter  his/her marks for term 1, term 2  and term 3 then he/she will get  the result.  
=======================================================================================================
Here is the list of stundent that Alread have an Account 
======================================================================================================
Username: Mduduzi
password : Mdu03

Username: Sandiso
password : Sa01

Username: Lucky
password : Lu02

Username: Mfanafuthi
password : Mdu00

Username: Danono
password : Mdu04

Username: Happy
password : Mdu05

Username: Mnyama
password : Mn01
==========================================================================================================
