var attempt = 3; 

function validate(){
	const obj = JSON.parse(user);
	var success = false;

	var usern = document.getElementById("username").value;
	var passw = document.getElementById("password").value;
	var i;
	
	for(i in obj){
	 
	  if((obj[i].uname == usern) && (obj[i].pword == passw))
	  {
		success = true;
		break;
	  }
	  else
         success = false;    	  
	}
	if(success)
	{
		alert("Welcome  "+usern + " You are successfully verified");
		window.location = "index.html";
	}
	else{
		attempt --;
		alert("You have left "+attempt+" attempt;");
		
		
	}
	if( attempt == 0){
		document.getElementById("username").disabled = true;
		document.getElementById("password").disabled = true;
		document.getElementById("submit").disabled = true;
		document.getElementById("info").innerHTML = "Please contact your administrator";
		return false;
	}
}
function clearInputError(inputElement) {
    inputElement.classList.remove("form__input--error");
    inputElement.parentElement.querySelector(".form__input-error-message").textContent = "";
}

document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.querySelector("#login");
    const createAccountForm = document.querySelector("#createAccount");

    document.querySelector("#linkCreateAccount").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.add("form--hidden");
        createAccountForm.classList.remove("form--hidden");
    });

    document.querySelector("#linkLogin").addEventListener("click", e => {
        e.preventDefault();
        loginForm.classList.remove("form--hidden");
        createAccountForm.classList.add("form--hidden");
    });